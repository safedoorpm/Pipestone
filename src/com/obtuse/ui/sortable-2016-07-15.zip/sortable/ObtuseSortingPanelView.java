package com.obtuse.ui.sortable;

/*
 * Copyright © 2015 Obtuse Systems Corporation
 */

import java.awt.*;

/**
 Something capable of showing a collection of sorted entities.
 */

public interface ObtuseSortingPanelView {

//    String checkOrder();

//    boolean reSort( Component component );

    void setSortingPanelModel( ObtuseSortingPanelModel sortingPanelModel );

    ObtuseSortingPanelModel getSortingPanelModel();
}
