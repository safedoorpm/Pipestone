package com.obtuse.ui.sortable;

import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import java.awt.*;

/*
 * Copyright © 2015 Obtuse Systems Corporation
 */

/**
 * Something which can live within a {@link ObtuseSortingPanelModel} and which is sorted by a string key.
 * <p/>
 * The string key is initially provided via this class's constructors.
 * It can be updated via a {@link #setSortingKey(K)} method.
 * If this instance's key is updated, this instance calls the {@link ObtuseSortingPanelModel#reSort} method in any {@link ObtuseSortingPanelModel} which contains this instance.
 */

@SuppressWarnings("UnusedDeclaration")
public abstract class ObtuseSortableEntity<K> extends JPanel implements ObtuseSortableEntityModel<K> {

    private K _sortingKey;

    public ObtuseSortableEntity( @NotNull K sortingKey ) {
        super();

	_sortingKey = sortingKey;

    }

    @Override
    public K getSortingKey() {

        return _sortingKey;

    }

    final
    void setSortingKey( K newSortingKey ) {

        _sortingKey = newSortingKey;

    }


    @Override
    public int compareTo( @NotNull ObtuseSortableEntityModel obtuseSortableJComponent ) {

        if ( obtuseSortableJComponent instanceof ObtuseSortableEntity ) {

            return _sortingKey.compareTo( ((ObtuseSortableEntity) obtuseSortableJComponent ).getSortingKey() );

        } else {

            throw new IllegalArgumentException( "ObtuseSortableEntity:  can only be compared to ObtuseSortableEntity instances" );

        }

    }

    public String toString() {

	return "ObtuseSortableEntity( \"" + getSortingKey() + "\" )";

    }

}
