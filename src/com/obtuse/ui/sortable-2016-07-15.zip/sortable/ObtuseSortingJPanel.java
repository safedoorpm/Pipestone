package com.obtuse.ui.sortable;

import com.obtuse.exceptions.HowDidWeGetHereError;
import com.obtuse.util.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.ref.WeakReference;
import java.util.*;
import java.util.List;

/*
 * Copyright © 2015 Obtuse Systems Corporation
 */

/**
 * A {@link JPanel} containing {@link ObtuseSortableEntityView}s.
 */

public class ObtuseSortingJPanel<K,V> extends JPanel implements ObtuseSortingPanelView {

    public static final int NWORDS = 100;

    private static final String[] s_words;

    static {

	SortedSet<String> words = new TreeSet<String>();
//	words.add( "alpha" );
//	words.add( "beta" );
//	words.add( "gamma" );
//	words.add( "turtles" );
//	words.add( "fish" );
//	words.add( "carrots" );
//	words.add( "words" );
//	words.add( "impala" );
//	words.add( "there" );
//	words.add( "world" );
//	words.add( "flash" );
//	words.add( "junk" );
//	words.add( "stuff" );
//	words.add( "street" );
//	words.add( "glunk" );
//	words.add( "elephant" );
//	words.add( "giraffe" );
//	words.add( "desk" );
//	words.add( "hat" );
//	words.add( "kettle" );
//	words.add( "lemon" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "glunk" );
//	words.add( "zebra" );

	for ( int i = 0; i < NWORDS; i += 1 ) {

	    words.add( NounsList.pickNoun() );

	}

	s_words = words.toArray( new String[words.size()] );

	ObtuseUtil.doNothing();

    }

    @SuppressWarnings("FieldCanBeLocal")
    private final BoxLayout _layoutManager;

    private ObtuseSortingPanelModel _sortingPanelModel;

    @SuppressWarnings("SameParameterValue")
    public ObtuseSortingJPanel( int axis ) {
        super();

        //noinspection MagicConstant,ThisEscapedInObjectConstruction
        _layoutManager = new BoxLayout( this, axis );
        super.setLayout( _layoutManager );

    }

    public void setLayout( LayoutManager layoutManager ) {

        if ( getLayout() == null ) {

            super.setLayout( layoutManager );

        } else {

            throw new IllegalArgumentException( "ObtuseSortingJPanel:  attempt to change layout manager once sorted JPanel has been created" );

        }

    }

    private void removeEntityAtIndices( List<Integer> indices, ObtuseSortableEntityModel<K> entity ) {

        SortedSet<Integer> reverseSortedIndices = new TreeSet<Integer>(
		new Comparator<Integer>() {

		    @Override
		    public int compare( Integer lhs, Integer rhs ) {

			return -lhs.compareTo( rhs );

		    }

		}
	);

	for ( int ix : reverseSortedIndices ) {

	    ObtuseSortableEntityView<K> thisEntityView = (ObtuseSortableEntityView<K>) getComponent( ix );
	    ObtuseSortableEntityModel<K> thisEntityModel = thisEntityView.getEntityModel();
	    if ( entity == thisEntityModel ) {

		remove( ix );

	    } else {

	        throw new HowDidWeGetHereError( "component at index " + ix + " does not reference an entity whose model is " + entity );

	    }

	}

    }

    //    public Component add( Component component ) {
//
//        if ( !( component instanceof ObtuseSortableEntityView ) ) {
//
//            throw new IllegalArgumentException( "ObtuseSortingJPanel.add:  components must implement ObtuseSortableEntityView interface" );
//
//        }
//
//        ObtuseSortableEntityView obtuseSortableJComponent = (ObtuseSortableEntityView)component;
//
//	_sortingPanelModel.addEntity(  );
//	int existingIx = findIndex( obtuseSortableJComponent );
//	if ( existingIx >= 0 ) {
//
//	    throw new IllegalArgumentException( "ObtuseSortingJPanel.add:  component already in this panel (" + component + ")" );
//
//	}
//
//	for ( int ix = 0; ix < getComponentCount(); ix += 1 ) {
//
//            ObtuseSortableEntityView existingComponent = (ObtuseSortableEntityView)getComponent( ix );
//            if ( obtuseSortableJComponent.compareTo( existingComponent ) <= 0 ) {
//
//                super.add( component, ix );
//
//                return component;
//
//            }
//
//        }
//
//        super.add( component );
//
//        return component;
//
//    }
//
//    public void remove( int ix ) {
//
//	super.remove( ix );
//
//    }
//
//    public void remove( Component component ) {
//
//	if ( !( component instanceof ObtuseSortableEntityView ) ) {
//
//	    throw new IllegalArgumentException( "ObtuseSortingJPanel.remove( " + component + "):  components must implement ObtuseSortableEntityView interface" );
//
//	}
//
//	super.remove( component );
//
//    }

//    @Override
//    public boolean reSort( Component component ) {
//
//	if ( component != null && !( component instanceof ObtuseSortableEntityView ) ) {
//
//	    throw new IllegalArgumentException( "ObtuseSortingJPanel.reSort:  requesting component is not a ObtuseSortableEntityView instance (" + component + ")" );
//
//	}
//
//	ObtuseSortableEntityView sortableComponent = (ObtuseSortableEntityView)component;
//
//	// Make sure that the requesting component, if specified, is one of our components.
//
//	if ( sortableComponent != null && findIndex( sortableComponent ) < 0 ) {
//
//	    throw new IllegalArgumentException( "ObtuseSortingJPanel.reSort: component requesting re-sort is not in this panel" );
//
//	}
//
//	// If our components are still in the correct order then we're done.
//
//	if ( _sortingPanelModel.checkOrder() == null ) {
//
//	    return false;
//
//	}
//
//	// If there was no requesting component specified then we need to do this the hard way.
//
//	if ( sortableComponent == null ) {
//
//	    forceReSort();
//
//	    return true;
//
//	}
//
//	// Remove the component that we have been told has changed.
//	// If we are not now sorted then force a re-sort.
//
//	remove( component );
//	if ( !_sortingPanelModel.checkOrder() ) {
//
//	    forceReSort();
//
//	}
//
//	// Re-add the changed component and we're done.
//
//	add( component );
//
//	return true;
//
//    }
//
//    public Component add( Component component, int ix ) {
//
//        throw new IllegalArgumentException(
//                "ObtuseSortingJPanel.add:  attempt to use add( Component comp, int index ), must use add( Component comp )"
//        );
//
//    }
//
//    public void add( @NotNull Component component, Object constraints ) {
//
//        throw new IllegalArgumentException(
//                "ObtuseSortingJPanel.add:  attempt to use add( Component comp, Object constraints ), must use add( Component comp )"
//        );
//
//    }
//
//    public void add( Component component, Object constraints, int ix ) {
//
//        throw new IllegalArgumentException(
//                "ObtuseSortingJPanel.add:  attempt to use add( Component comp, Object constraints, int index ), must use add( Component comp )"
//        );
//
//    }
//
//    public Component add( String name, Component component ) {
//
//        throw new IllegalArgumentException(
//                "ObtuseSortingJPanel.add:  attempt to use add( String name, Component comp ), must use add( Component comp )"
//        );
//
//    }
//
//    private static class MyJPanel extends JPanel implements ObtuseSortableEntityView {
//
//        private final String _label;
//
//        private MyJPanel( String label ) {
//            super();
//
//            _label = label;
//
//        }
//
//        public int compareTo( @NotNull ObtuseSortableEntityView rhs ) {
//
//            return _label.compareTo( ((MyJPanel)rhs).getLabel() );
//
//        }
//
//        public String getLabel() {
//
//            return _label;
//
//        }
//
//    }

    private static Random s_rng = new Random( System.currentTimeMillis() );

    private static int s_nextIx = 0;

    private static class MyEntityModel extends ObtuseSortableEntity<String> {

        private MyEntityModel( String key ) {
            super( key );

	}

	@Override
	public JComponent createSortableEntityView() {

	    return null;
	}

//	@Override
//	public void setSortingKey( String newSortingKey ) {
//
//	}

	@Override
	public int compareTo( @NotNull ObtuseSortableEntityView obtuseSortableJComponent ) {

	    return 0;
	}
    }

    private static JPanel makeJPanel( final String label ) {

        final ObtuseSortableEntity<String> panel = new MyEntityModel( label );
        panel.setLayout( new BoxLayout( panel, BoxLayout.X_AXIS ) );
        final JButton before = new JButton( "add before" );
	JButton after = new JButton( "add after" );
	final JLabel ourLabel = new JLabel( label );
	panel.add( new JLabel( "" + s_nextIx ) );
	s_nextIx += 1;
	panel.add( before );
	panel.add( after );
	panel.add( ourLabel );

	before.addActionListener(
                new ActionListener() {

                    public void actionPerformed( ActionEvent actionEvent ) {

                        Logger.logMsg( "someone clicked the add before \"" + panel.getSortingKey() + "\" button" );
			int wordIx = findWord( panel.getSortingKey() );
			if ( wordIx > 0 ) {

			    int newIx = s_rng.nextInt( wordIx + 1 );
			    if ( newIx > wordIx ) {

				throw new IllegalArgumentException( "rng problem 1 in makeJPanel" + " (wordIx=" + wordIx + ", newIx=" + newIx + ")" );

			    }

			    Logger.logMsg( "\"" + panel.getSortingKey() + "\" becomes \"" + s_words[newIx] + "\"" );

			    panel.setSortingKey( s_words[newIx] );
			    String newLabel = panel.getSortingKey();
			    if ( !newLabel.equals( s_words[newIx] ) ) {

				throw new IllegalArgumentException( "panel key change did not stick" );

			    }

			    ourLabel.setText( panel.getSortingKey() );

			    if ( !newLabel.equals( ourLabel.getText() ) ) {

				throw new IllegalArgumentException( "button label change did not stick" );

			    }

//			    panel.invalidate();

			}

                    }

                }
        );

	after.addActionListener(
		new ActionListener() {

		    public void actionPerformed( ActionEvent actionEvent ) {

			Logger.logMsg( "someone clicked the add after \"" + panel.getSortingKey() + "\" button" );
			int wordIx = findWord( panel.getSortingKey() );
			if ( wordIx < s_words.length - 1 ) {

			    int newIx = wordIx + s_rng.nextInt( s_words.length - wordIx );

			    if ( newIx < wordIx ) {

				throw new IllegalArgumentException( "rng problem 2 in makeJPanel" + " (wordIx=" + wordIx + ", newIx=" + newIx + ")" );

			    }

			    if ( newIx >= s_words.length ) {

				throw new IllegalArgumentException( "rng problem 3 in makeJPanel" + " (wordIx=" + wordIx + ", newIx=" + newIx + ")" );

			    }

			    Logger.logMsg( "\"" + panel.getSortingKey() + "\" becomes \"" + s_words[newIx] + "\"" );

			    panel.setSortingKey( s_words[newIx] );
			    String newLabel = panel.getSortingKey();
			    if ( !newLabel.equals( s_words[newIx] ) ) {

				throw new IllegalArgumentException( "panel key change did not stick" );

			    }

			    ourLabel.setText( panel.getSortingKey() );

			    if ( !newLabel.equals( ourLabel.getText() ) ) {

				throw new IllegalArgumentException( "button label change did not stick" );

			    }

//			    panel.invalidate();

			}

		    }

		}
	);

        return panel;

    }

    private static int findWord( String word ) {

	for ( int i = 0; i < s_words.length; i += 1 ) {

	    if ( word.equals( s_words[i] ) ) {

		return i;

	    }

	}

	throw new IllegalArgumentException( "word \"" + word + " not found" );

    }

    @SuppressWarnings("UnqualifiedStaticUsage")
    public static void main( String[] args ) {

        BasicProgramConfigInfo.init( "Obtuse", "Pipestone", "ObtuseSortingJPanel", null );

        JFrame topFrame = new JFrame();

        ObtuseSortingJPanel sjp = new ObtuseSortingJPanel( BoxLayout.Y_AXIS );
	for ( int i = 0; i < NWORDS; i += 1 ) {

	    sjp.add( makeJPanel( s_words[i] ) );

	}
//        sjp.add( makeJPanel( "There" ) );
//        sjp.add( makeJPanel( "World" ) );
//        sjp.add( makeJPanel( "Hello" ) );
//        sjp.add( makeJPanel( " starts with space" ) );
//        sjp.add( makeJPanel( "Zee Last One" ) );

	JScrollPane pane = new JScrollPane( sjp );
        topFrame.setContentPane( pane );
        topFrame.pack();
        topFrame.setVisible( true );

    }

    @Override
    public void setSortingPanelModel( ObtuseSortingPanelModel sortingPanelModel ) {

	if ( _sortingPanelModel != null && _sortingPanelModel != sortingPanelModel ) {

	    _sortingPanelModel = sortingPanelModel;

	    sortingPanelModel.setSortingJPanel( this );
	}

	_sortingPanelModel = sortingPanelModel;

    }

    @Override
    public ObtuseSortingPanelModel getSortingPanelModel() {

	return _sortingPanelModel;

    }

    /**
     A model for managing sorted sets of things that might appear in an {@link ObtuseSortingJPanel}.
     */

    public static class ObtuseSortingJPanelDefaultModel<K extends Comparable<K>,V> implements ObtuseSortingPanelModel<K> {

	private TreeSorter<K,ObtuseSortableEntityModel> _mapping;

    //    private WeakHashMap<ObtuseSortingJPanel,WeakReference<ObtuseSortingJPanel>> _ourSortingJPanels;

	WeakReference<ObtuseSortingJPanel> _ourSortingJPanel;

	/**
	 Do something via one of our 'helper' methods.
	 @param <T> The return type of whatever doit returns.
	 */

	private abstract class SortingJPanelRunnable<T> {

	    public abstract T doit( ObtuseSortingJPanel<K,V> sortingPanel );

	}

	/**
	 Create an initially empty sorting JPanel model.
	 */

	public ObtuseSortingJPanelDefaultModel() {
	    this( new TreeSorter<K, ObtuseSortableEntityModel>() );

	}

	/**
	 Create a sorting JPanel and populate it with some initial elements.
	 @param initialEntities a mapping of sorting keys to the initial elements.
	 */

	public ObtuseSortingJPanelDefaultModel( TreeSorter<K,ObtuseSortableEntityModel> initialEntities ) {
	    super();

	    _mapping = new TreeSorter<K, ObtuseSortableEntityModel>( initialEntities );

	}

	/**
	 Verify that the entity views in this model's {@link ObtuseSortingJPanel} are correctly sorted.
	 @return null if they are properly sorted or if our {@link ObtuseSortingJPanel} has never been set or no longer exists; otherwise, a message explaining at least one problem.
	 */

	@Override
	public String checkOrder() {

	    return doSomethingToOurSortingJPanel(

		    new SortingJPanelRunnable<String>() {

			@Override
			public String doit( ObtuseSortingJPanel sortingJPanel ) {

			    if ( sortingJPanel.getComponentCount() == 0 ) {

				return null;

			    }

			    ObtuseSortableEntityView<K> prev = getEntityViewAtIndex( sortingJPanel, 0 );
			    ObtuseSortableEntityModel<K> prevModel = prev.getEntityModel();

			    for ( int ix = 1; ix < sortingJPanel.getComponentCount(); ix += 1 ) {

				ObtuseSortableEntityView<K> next = getEntityViewAtIndex( sortingJPanel, ix );
				ObtuseSortableEntityModel<K> nextModel = next.getEntityModel();
				int comparison = prevModel.compareTo( nextModel );
				if ( comparison > 0 ) {

				    return "element " + prev + " at ix=" + ( ix - 1 ) + " is greater than element " + next + " at ix=" + ix;

				}

				prev = next;
				prevModel = nextModel;

			    }


			    return null;

			}
		    }
	    );



	}

	private ObtuseSortableEntityView<K> getEntityViewAtIndex( Container container, int ix ) {

	    Component component = container.getComponent( 0 );
	    if ( component instanceof ObtuseSortableEntityView ) {

		//noinspection unchecked
		return (ObtuseSortableEntityView<K>) component;

	    } else {

		throw new HowDidWeGetHereError( "weird thing found in container:  " + component );

	    }

	}

	@Override
	public void setSortingJPanel( @Nullable ObtuseSortingJPanel sortingJPanel ) {

	    if ( sortingJPanel == null ) {

		_ourSortingJPanel = null;

		return;

	    }

	    if ( _ourSortingJPanel == null ) {

		_ourSortingJPanel = new WeakReference<ObtuseSortingJPanel>( sortingJPanel );

	    } else {

		ObtuseSortingJPanel ourCurrentSortingJPanel = _ourSortingJPanel.get();

		if ( _ourSortingJPanel.get() == null ) {

		    _ourSortingJPanel = new WeakReference<ObtuseSortingJPanel>( sortingJPanel );

		} else {

		    throw new IllegalArgumentException( "we already have a sorting JPanel (have " +
							ourCurrentSortingJPanel +
							", asked to use " +
							sortingJPanel +
							")"
		    );

		}

	    }

	    sortingJPanel.removeAll();
	    for ( ObtuseSortableEntityModel entityModel : _mapping.getAllValues() ) {

		sortingJPanel.add( entityModel.createSortableEntityView() );

	    }

	    sortingJPanel.setSortingPanelModel( this );

	}

	@Override
	public void changeSortingKey( K newSortingKey, ObtuseSortableEntity<K> entity ) {

	    removeAll( entity.getSortingKey(), entity );
	    entity.setSortingKey( newSortingKey );
	    addEntity( entity.getSortingKey(), entity );

    //	Container parent = getParent();
    //	if ( parent instanceof ObtuseSortingPanelView ) {
    //
    //	    ObtuseSortingPanelView sortingJPanel = (ObtuseSortingPanelView)parent;
    //
    //	    sortingJPanel.getSortingPanelModel().removeAll( _sortingKey, this );
    //	    _sortingKey = newSortingKey;
    //	    sortingJPanel.getSortingPanelModel().addEntity( _sortingKey, this );
    //	}
    //
    //	_sortingKey = newSortingKey;
    //
    //	Container parent = getParent();
    //	if ( parent instanceof ObtuseSortingPanelView ) {
    //
    //	    ObtuseSortingPanelView sortingJPanel = (ObtuseSortingPanelView)parent;
    //
    //	    sortingJPanel.reSort( this );
    //	    String orderingStatusMessage = sortingJPanel.getSortingPanelModel().checkOrder( parent );
    //	    if ( orderingStatusMessage != null ) {
    //
    //		throw new IllegalArgumentException( "ObtuseSortableEntity.setSortingKey: re-sort failed:  " + orderingStatusMessage );
    //
    //	    }
    //
    //	}

	}

	private void removeAll( K sortingKey, final ObtuseSortableEntity<K> entity ) {

	    final java.util.List<Integer> indices = _mapping.getAllValueIndices( sortingKey, entity );

	    doSomethingToOurSortingJPanel(
		    new SortingJPanelRunnable<ObtuseSortingJPanel<K,V>>() {

			@Override
			public ObtuseSortingJPanel<K,V> doit( ObtuseSortingJPanel sortingPanel ) {

			    sortingPanel.removeEntityAtIndices( indices, entity );

			    return sortingPanel;

			}

		    }
	    );

	}

	public void removeAll() {

	    _mapping.clear();

	}

	@Override
	public void addEntity( @NotNull Object key, @NotNull ObtuseSortableEntityModel entity ) {

	    addEntity( key, entity, false );

	}

	@Override
	public void addEntity( @NotNull Object key, @NotNull ObtuseSortableEntityModel entity, boolean replaceOk ) {

	    int existingIx = findActualEntityIndex( entity );

	    if ( existingIx >= 0 ) {

		throw new IllegalArgumentException(
			"ObtuseSortingJPanelDefaultModel.addEntity( [" + key + "] -> {" + entity + "} ):  component already in this panel"
		);

	    }

	    int existingKeyIx = findEqualKeyIndex( key );
	    if ( existingKeyIx >= 0 ) {

		if ( replaceOk ) {

		    _mapping.remove( key );
		    removeEntityFromSortingJPanelsAtIndex( existingKeyIx );

		} else {

		    throw new IllegalArgumentException(
			    "ObtuseSortingJPanelDefaultModel.addEntity( [" + key + "] -> {" + entity + "} ):  key already in this panel"
		    );

		}

	    }

	    _mapping.put( key, entity );
	    int newKeyIx = findEqualKeyIndex( key );
	    addEntityIntoOurSortingJPanelAtIndex( newKeyIx, entity );

	}

//	public void reSort( @NotNull Object key, @NotNull ObtuseSortableEntityModel entity ) {
//
//	    int existingIx = findActualEntityIndex( entity );
//	    if ( existingIx >= 0 ) {
//
//		removeEntityFromSortingJPanelsAtIndex( existingIx );
//
//	    }
//
//	    addEntity( key, entity, true );
//
//	}

//	private void removeEntityFromSortingJPanelsAtIndex( final int existingIx ) {
//
//	    doSomethingToOurSortingJPanel(
//		    new SortingJPanelRunnable<ObtuseSortingJPanel>() {
//
//			@Override
//			public ObtuseSortingJPanel doit( ObtuseSortingJPanel sortingPanel ) {
//
//			    sortingPanel.remove( existingIx );
//
//			    return sortingPanel;
//
//			}
//
//		    }
//	    );
//
//    //	ObtuseSortingJPanel ourCurrentSortingJPanel = getCurrentSortingJPanel();
//    //	if ( ourCurrentSortingJPanel == null ) {
//    //
//    //	    return;
//    //
//    //	}
//    //
//    //        ourCurrentSortingJPanel.remove( existingIx );
//
//    //	doSomethingToAllContainers(
//    //		new SortingJPanelRunnable() {
//    //
//    //		    public void doit( ObtuseSortingJPanel sortingPanel ) {
//    //
//    //			sortingPanel.remove( existingIx );
//    //
//    //		    }
//    //
//    //		}
//    //	);
//
//	}

	public <T> T doSomethingToOurSortingJPanel( SortingJPanelRunnable<T> runnable ) {

	    ObtuseSortingJPanel ourCurrentSortingJPanel = getCurrentSortingJPanel();
	    if ( ourCurrentSortingJPanel == null ) {

		return null;

	    }

	    return runnable.doit( ourCurrentSortingJPanel );

	}

	@Nullable
	public ObtuseSortingJPanel getCurrentSortingJPanel() {

	    if ( _ourSortingJPanel == null ) {

		return null;

	    }

	    ObtuseSortingJPanel ourCurrentSortingJPanel = _ourSortingJPanel.get();

	    if ( ourCurrentSortingJPanel == null ) {

		return null;

	    }

	    return ourCurrentSortingJPanel;

	}

	private void addEntityIntoOurSortingJPanelAtIndex( final int existingIx, final ObtuseSortableEntityModel entity ) {

	    doSomethingToOurSortingJPanel(
		    new SortingJPanelRunnable<ObtuseSortingJPanel>() {

			@Override
			public ObtuseSortingJPanel doit( ObtuseSortingJPanel sortingPanel ) {

			    sortingPanel.add( entity.createSortableEntityView(), existingIx );

			    return sortingPanel;

			}

		    }
	    );

    //	doSomethingToAllContainers(
    //		new SortingJPanelRunnable() {
    //
    //		    public void doit( ObtuseSortingJPanel sortingPanel ) {
    //
    //			sortingPanel.add( entity.createComponent(), existingIx );
    //
    //		    }
    //
    //		}
    //	);

	}

    //    /**
    //     Do something to all of our {@link ObtuseSortingJPanel}s.
    //     @param doitRunnable what needs to be done to each one.
    //     */
    //
    //    private void doSomethingToAllContainers( SortingJPanelRunnable doitRunnable ) {
    //
    //	// Grab strong references to all still existent containers that use our services.
    //
    //	java.util.List<ObtuseSortingJPanel> containers = new LinkedList<ObtuseSortingJPanel>();
    //	for ( ObtuseSortingJPanel con : _ourSortingJPanels.keySet() ) {
    //
    //	    containers.add( con );
    //
    //	}
    //
    //	for ( ObtuseSortingJPanel con : containers ) {
    //
    //	    doitRunnable.doit( con );
    //
    //	}
    //
    //    }

	public int findEqualKeyIndex( Object targetKey ) {

	    if ( !_mapping.containsKey( targetKey ) ) {

		return -1;

	    }

	    int ix = 0;
	    for ( Object existingEntity : _mapping.keySet() ) {

		if ( targetKey == existingEntity ) {

		    return ix;

		}

	    }

	    return -1;

	}

	public int findActualEntityIndex( ObtuseSortableEntityModel targetEntity ) {

	    int ix = 0;
	    for ( ObtuseSortableEntityModel existingEntity : _mapping.values() ) {

		if ( targetEntity == existingEntity ) {

		    return ix;

		}

	    }

	    return -1;

	}

	/**
	 Force a sort of our components.
	 */

	@Override
	public void forceReSort() {

	    // Just re-add everything.

	    TreeMap<Object,ObtuseSortableEntityModel> everything = new TreeMap<Object, ObtuseSortableEntityModel>( _mapping );

	    removeAll();

	    for ( Object key : everything.keySet() ) {

		ObtuseSortableEntityModel entity = everything.get( key );
		addEntity( key, entity );

	    }

	}

    //    @Override
    //    public boolean checkOrder() {
    //
    //	Component[] components = getComponents();
    //	if ( components.length <= 1 ) {
    //
    //	    return true;
    //
    //	}
    //
    //	ObtuseSortableEntityView prev = (ObtuseSortableEntityView) components[0];
    //	for ( int ix = 1; ix < components.length; ix += 1 ) {
    //
    //	    ObtuseSortableEntityView next = (ObtuseSortableEntityView) components[ix];
    //	    if ( prev.compareTo( next ) > 0 ) {
    //
    //		return false;
    //
    //	    }
    //
    //	    prev = next;
    //
    //	}
    //
    //	return true;
    //
    //    }

    }

}
