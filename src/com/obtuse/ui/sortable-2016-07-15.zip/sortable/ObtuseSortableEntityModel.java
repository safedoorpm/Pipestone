package com.obtuse.ui.sortable;

/*
 * Copyright © 2015 Obtuse Systems Corporation
 */

import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * Something that can live within and be managed by a {@link ObtuseSortingJPanel.ObtuseSortingJPanelDefaultModel}.
 */

public interface ObtuseSortableEntityModel<K> extends Comparable<ObtuseSortableEntityModel> {

    JComponent createSortableEntityView();

    K getSortingKey();

    int compareTo( @NotNull ObtuseSortableEntityView obtuseSortableJComponent );

}
