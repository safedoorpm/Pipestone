package com.obtuse.ui.sortable;

/*
 * Copyright © 2015 Obtuse Systems Corporation
 */

import org.jetbrains.annotations.NotNull;

import java.awt.*;
import java.util.Collection;

/**
 A model for managing sorted sets of things that might appear in a {@link ObtuseSortingJPanel}.
 */

public interface ObtuseSortingPanelModel<K> {

//    void reSort( @NotNull Object key, @NotNull ObtuseSortableEntityModel entity );

    void forceReSort();

//    boolean checkOrder();

    void setSortingJPanel( @NotNull ObtuseSortingJPanel sortingJPanel );

    public void changeSortingKey( K newSortingKey, ObtuseSortableEntity<K> entity );

    void addEntity( @NotNull Object key, @NotNull ObtuseSortableEntityModel entity, boolean replaceOk );

    void addEntity( @NotNull Object key, @NotNull ObtuseSortableEntityModel entity );

    void removeAll();

    String checkOrder();

}
