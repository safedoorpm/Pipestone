package com.obtuse.ui.sortable;

/*
 * Copyright © 2015 Obtuse Systems Corporation
 */

import org.jetbrains.annotations.NotNull;

/**
 * Something that can live within and be managed by a {@link ObtuseSortingJPanel}.
 * <p/>These 'somethings' must be JComponents.
 */

public interface ObtuseSortableEntityView<K> extends Comparable<ObtuseSortableEntityView> {

    ObtuseSortableEntityModel<K> getEntityModel();

}
